// DepressionQuestions.js
const depressionQuestions = [
        "I couldn't seem to experience any positive feeling at all", 
        "I just couldn't seem to get going",
        "I felt that I had nothing to look forward to",
        "I felt sad and depressed",
        "I felt that I had lost interest in just about everything",
        "I felt I wasn't worth much as a person", 
        "I felt that life wasn't worthwhile",
        "I couldn't seem to get any enjoyment out of the things I did", 
        "I felt down-hearted and blue", 
        "I was unable to become enthusiastic about anything", 
        "I felt I was pretty worthless", 
        "I could see nothing in the future to be hopeful about",
        "I felt that life was meaningless", 
        "I found it difficult to work up the initiative to do things "
  ];
  
  export default depressionQuestions;
  